import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ServicesComponent } from './services/services.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { ProductsComponent } from './products/products.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Redirect to 'home' by default
  { path: 'home', component: HomeComponent },
  { path: 'product', component: ProductsComponent },
  { path: 'about', component: AboutComponent },
  {path:'services',component:ServicesComponent},
  {path:'registration',component:RegistrationComponent},

  
  { path: '**', redirectTo: '/home' } // Handle any other routes by redirecting to 'home'
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
