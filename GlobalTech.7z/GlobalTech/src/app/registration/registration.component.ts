import { Component } from '@angular/core';
import { Registration } from '../registration';
import { RegistrationService } from '../registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent  {





r: Registration = new Registration();
  constructor(private registrationService: RegistrationService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveRegistration(){
    this.registrationService.createregistration(this.r).subscribe( (data: any) =>{
      console.log(data);
      this.goToRegistrationList();
    },
    error => console.log(error));
  }

  goToRegistrationList(){
    this.router.navigate(['/Registration']);
  }
  
  onSubmit(){
    console.log(this.r);
    this.saveRegistration();
  }
}

