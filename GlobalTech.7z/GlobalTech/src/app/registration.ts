export class Registration {
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
    username!:string;
    password!:string;
}