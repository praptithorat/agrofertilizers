import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent implements OnInit {

  // Define array of services
  services = [
    {
      title: 'Service 1',
      description: 'Description of Service 1.',
      link: 'https://example.com/service1',
      images: [
        'app/assets/images/logo.jpg',
        'assets/images/service1-image2.jpg',
        'assets/images/service1-image3.jpg'
      ]
    },
    {
      title: 'Service 2',
      description: 'Description of Service 2.',
      link: 'https://example.com/service2',
      images: [
        'assets/images/logo.jpg',
        'assets/images/service2-image2.jpg',
        'assets/images/service2-image3.jpg'
      ]
    }
    // Add more services as needed
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
